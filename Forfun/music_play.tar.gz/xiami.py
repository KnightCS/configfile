#!/usr/bin/python
# -*- coding: UTF-8 -*-
from decode import *
import subprocess
import time
import thread
import sys
try:
    from subprocess import DEVNULL
except ImportError:
    import os
    DEVNULL = open(os.devnull, 'w')

def music_list(source):
    def max_len(a):
        if a >= 10:
            return 21 + 6
        else:
            return 21 + a
    print 'Number| ' + 'Music name'.center(20) + '|' + 'Music artist'.center(21) + '|' + 'Music album'.center(20)
#    print 'Number| ' + \
#            '{0: ^20}| {1: ^20} | {2: ^20}'.format('Music name','Music artist','music album')
#    print '----------------------------------------------------------------------'
#    for j in range(len(source)):
#        print ' -{0:0>2d}- | {1: <20}  |  {2: <20}  | {3: <20}'.format(j+1, \
#                source[j]['name'], source[j]['artist'], source[j]['album'])
    print '----------------------------------------------------------------------'
    for j in range(len(source)):
        print ('-%02d-'%(j)).center(6) + '|' + \
                '%s'%(source[j]['name'][:28]).ljust(max_len(len(source[j]['name'])/3)) + '|' +\
                '%s'%(source[j]['artist'][:28]).ljust(max_len(len(source[j]['artist'])/3)) + '|' +\
                source[j]['album']
                #('%s'%(source[j]['name'])).ljust(len(source[j]['name'])+(20 - len(source[j]['name'])* 2)) + '|'
    print '----------------------------------------------------------------------'

    while 1:
        try:
            number = int(raw_input("Which music do you want to play?(input the number):"))
        except:
            print 'Please input number.'
        else:
            break
    if len(source) == 0:
        return -1
    elif number <= len(source):
        return number-1
    else:
        return len(source)-1

def search():
    search_name = raw_input("Input the music name:")
    print '----------------------------------------------------------------------'
    result = search_music(search_name)
    number = music_list(result)
    if number == -1:
        print 'No music as %s, please re-search.'%(search_name)
        return search()
    return (result, number)

def play(result, number):
    child = subprocess.Popen(['mpg123', get_play_url(result[number]['code'])],\
            stdout=DEVNULL, stderr=DEVNULL)
    print
    print '----------------------------------------------------------------------'
    print '*Name:  * ' + result[number]['name']
    print '*Autist:* ' + result[number]['artist']
    print '*Album: * ' + result[number]['album']
    print '----------------------------------------------------------------------'
    print '(s)search (n)next (e)exit (v)volume (d)download'
    print '----------------------------------------------------------------------'
    return child

def play_next(result, number, child):
    if number >= len(result):
        number = 0
    if child.poll() != 0:
        child.kill()
    return play(result, number)

def volume():
    volume = subprocess.Popen("alsamixer")
    volume.wait()

def exit_sys(child):
    if child.poll() != 0:
        child.kill()
    DEVNULL.close()
    sys.exit(0)

def download_music(source, number):
    child = subprocess.Popen(['wget', '-O',\
            'music/' + source[number]['name']+'.mp3',\
            get_play_url(source[number]['code'])], \
            stdout=DEVNULL, stderr=DEVNULL)

def keep_play():
    global child, musicList, musicNumber

    while 1:
        if child.poll() == 0:
            #防止切歌时多次增加
            time.sleep(0.1)
            if child.poll() == 0:
                if musicNumber < len(musicList) - 1:
                    musicNumber += 1
                else:
                    musicNumber = 0
                child = play_next(musicList, musicNumber, child)

print '----------------------------------------------------------------------'
print 'Welcome to use xiami music. '
print 'Please chose the function:'
print '(s)search (n)next (e)exit (v)volume (d)download'
print '----------------------------------------------------------------------'
(musicList, musicNumber) = search()
child = play(musicList, musicNumber)
thread.start_new_thread(keep_play, ())
while 1:
    comman = raw_input("You order:")
    print '----------------------------------------------------------------------'
    if comman == 'search' or comman == 's':
        (musicList, musicNumber) = search()
        child = play_next(musicList, musicNumber, child)
    elif comman == 'next' or comman == 'n':
        if musicNumber < len(musicList) - 1:
            musicNumber += 1
        else:
            musicNumber = 0
        child = play_next(musicList, musicNumber, child)
    elif comman == 'volume' or comman == 'v':
        volume()
    elif comman == 'exit' or comman == 'e':
        exit_sys(child)
    elif comman == 'download' or comman == 'd':
        download_music(musicList, musicNumber)
    else:
        print '----------------------------------------------------------------------'
        print '(s)search (n)next (e)exit (v)volume (d)download'
        print '----------------------------------------------------------------------'
        print 'Input error, please re-enter.'
