#!/usr/bin/python
# -*- encoding:utf-8 -*-
import urllib
import urllib2
import re

def request_open(url):
    #user_header
    user_agent = r'Mozilla/5.0 (compatible; Konqueror/3.2; FreeBSD) (KHTML, like Gecko)'
    values = {
            'name' : 'Michael Foord',
            'location' : 'Northampton',
            'language' : 'Python'
            }
    headers = { 'User-Agent' : user_agent }

    # get Request and decode
    data = urllib.urlencode(values)
    req = urllib2.Request(url, data, headers)
    page = urllib2.urlopen(req)
    the_page = page.read()
    return the_page

def get_downloadcode(musicName):
    url = u'http://www.xiami.com/search?'
    data = {'pos': '1'}
    data['key'] = musicName
    urlSearch = url + urllib.urlencode(data)

    # the url of the music search
    the_page = request_open(urlSearch)

    found = re.search(r'<a target="_blank" href="http://www.xiami.com/song/(.+?)" title="(.+?)">(.+?)</b></a>', the_page)
    return found.group(1)

def get_decode(downloadCode):
    # set url data headers
    sourceurl = r'http://www.xiami.com/widget/xml-single/uid/0/sid/'
    url = sourceurl + str(downloadCode)
    respHtml = request_open(url)
    foundLocation = re.search(r'<location>(?P<location>.+?)</location>', respHtml)
    source = foundLocation.group()
    encode = source[19:(len(source)-14)]
    return encode

def xiami_decode(s):
    s = s.strip()
    if not s:
        return False
    result = []
    line = int(s[0])
    rows = len(s[1:]) / line
    extra = len(s[1:]) % line
    s = s[1:]

    for x in xrange(extra):
        result.append(s[(rows + 1) * x:(rows + 1) * (x + 1)])

    for x in xrange(line - extra):
        result.append(s[(rows + 1) * extra + (rows * x):(rows + 1) \
                * extra + (rows * x) + rows])

    url = ''

    for x in xrange(rows + 1):
        for y in xrange(line):
            try:
                url += result[y][x]
            except IndexError:
                continue

    url = urllib2.unquote(url)
    url = url.replace('^', '0')
    return url

def get_play_url(code):
    return xiami_decode(get_decode(code))

def search_music(musicName):
    url = r'http://www.xiami.com/search?'
    data = {'pos': '1',}
    data['key'] = musicName
    urlSearch = url + urllib.urlencode(data)

    the_page = request_open(urlSearch)
    the_page = the_page.replace(r'<b class="key_red">', '')
    the_page = the_page.replace(r'</b>', '')

    code_name = re.findall(r'<a target="_blank" href="http://www.xiami.com/song/(.+?)" title="(.+?)">([\s]*)(.*?)([\s]*)</a>', the_page)
    artist = re.findall(r'<a target="_blank" href="http://www.xiami.com/artist/(.+?)" title="(.+?)">([\s]*)(.*?)([\s]*)</a>', the_page)
    album = re.findall(r'<a target="_blank" href="http://www.xiami.com/album/(.+?)" title="(.+?)">([\s]*)(.+?)([\s]*)</a>', the_page)

    search_result = []
    for i in range(len(code_name)):
        music_dict = {}
        music_dict['code'] = code_name[i][0]
        music_dict['name'] = code_name[i][3]
        music_dict['artist'] = artist[i][3]
        music_dict['album'] = album[i][3]
        search_result.append(music_dict.copy())

    return search_result

if __name__ == '__main__':
    url = r'http://www.xiami.com/search?'
    data = {'pos': '1',}
    data['key'] = "明年今日"
    urlSearch = url + urllib.urlencode(data)
    the_page = request_open(urlSearch)
    print the_page
